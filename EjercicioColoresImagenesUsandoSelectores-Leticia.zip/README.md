# Bordes-colores-e-im-genes-usando-selectores-diversos
Ejercicio CSS3 para la asignatura de Lenguaje de Marcas
